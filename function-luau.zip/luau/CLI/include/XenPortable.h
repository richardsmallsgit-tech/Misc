#pragma once
struct lua_State;
void luaopen_xen_portable(lua_State* L);
