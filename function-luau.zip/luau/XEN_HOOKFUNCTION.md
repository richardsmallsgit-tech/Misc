# Xen hookfunction integration

This source tree contains a VM-level hook resolver used by the portable Xen API.

## How it works

- `CLI/src/XenPortable.cpp` stores target-function -> replacement-function pairs in a table rooted in `LUA_REGISTRYINDEX`.
- `VM/src/ldo.cpp` owns the private registry key and implements `luaX_resolvehook`.
- The VM calls the resolver at function-call boundaries, including the interpreter call paths in `VM/src/lvmexecute.cpp` and the protected/API call path in `VM/src/ldo.cpp`.
- The resolver replaces the function value in the active call slot before normal dispatch. This is why the registry table alone would not be sufficient: the VM must consult it.

## Current API behavior

`hookfunction(target, replacement)` accepts both Luau and native C closures and returns a clone of the original closure. The hook is associated with the original function object, so aliases that refer to that same object are also redirected. Re-hooking a target returns the previous replacement as the prior behavior.

`lua_clonefunction` now clones either closure representation. For C closures it preserves the native function pointer, continuation, debug name, environment, and every captured upvalue. This is important: copying only the C function pointer would silently break closures that capture state or use continuation-based yielding. The VM-level hook resolver remains type-agnostic and redirects the active call slot before normal dispatch.

## Smoke test

Run `tests/xen_hook_smoke.luau` with the built Luau REPL executable. It checks aliases, multiple return values, calls made from another function, and the `xen.hookfunction` alias.
