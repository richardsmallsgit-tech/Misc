@echo off
setlocal EnableExtensions
title Build Luau Distribution

REM Put this BAT and dist-wrapper-CMakeLists.txt in the Luau source root (beside CMakeLists.txt).
REM Output (dist\):  luau.exe  wluau.exe  luauc.exe  luau.dll  lib\luau.lib  include\
REM luau.exe / wluau.exe are thin launchers; the interpreter + CodeGen live in luau.dll.

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "WRAP=%ROOT%\build-wrapper-src"
set "BUILD=%ROOT%\build-distribution-clean"
set "DIST=%ROOT%\dist"

where cmake >nul 2>nul || (echo [ERROR] cmake not on PATH & goto :fail)
if not exist "%ROOT%\CMakeLists.txt" (echo [ERROR] not in Luau root & goto :fail)
if not exist "%ROOT%\dist-wrapper-CMakeLists.txt" (echo [ERROR] dist-wrapper-CMakeLists.txt missing & goto :fail)

if exist "%BUILD%" rmdir /s /q "%BUILD%"
if exist "%WRAP%" rmdir /s /q "%WRAP%"
mkdir "%WRAP%"
copy /Y "%ROOT%\dist-wrapper-CMakeLists.txt" "%WRAP%\CMakeLists.txt" >nul

echo [1/4] Configure
set "ROOTFWD=%ROOT:\=/%"
cmake -S "%WRAP%" -B "%BUILD%" -G "Visual Studio 17 2022" -A x64 -DLUAU_ROOT="%ROOTFWD%" -DLUAU_STATIC_CRT=ON
if errorlevel 1 goto :fail

echo [2/4] Build
for %%T in (Luau.Compile.CLI LuauDLL luau_launcher wluau_launcher) do (
    echo   - %%T
    cmake --build "%BUILD%" --config Release --target %%T
    if errorlevel 1 goto :fail
)

echo [3/4] Package
if exist "%DIST%" rmdir /s /q "%DIST%"
mkdir "%DIST%" & mkdir "%DIST%\include" & mkdir "%DIST%\include\Luau" & mkdir "%DIST%\lib"

set "INTERP=" & set "COMPILER=" & set "WEXE=" & set "DLL=" & set "IMP="
for /r "%BUILD%\launcher" %%F in (luau.exe)  do if exist "%%F" if not defined INTERP set "INTERP=%%F"
for /r "%BUILD%\launcher" %%F in (wluau.exe) do if exist "%%F" if not defined WEXE   set "WEXE=%%F"
for /r "%BUILD%" %%F in (luau-compile.exe)   do if exist "%%F" if not defined COMPILER set "COMPILER=%%F"
for /r "%BUILD%" %%F in (luau.dll)           do if exist "%%F" if not defined DLL    set "DLL=%%F"
for /r "%BUILD%" %%F in (luau.lib)           do if exist "%%F" if not defined IMP    set "IMP=%%F"
echo   found: INTERP=%INTERP%
echo   found: WEXE=%WEXE%
echo   found: COMPILER=%COMPILER%
echo   found: DLL=%DLL%
echo   found: IMPLIB=%IMP%

if not defined INTERP   (echo [ERROR] luau.exe missing & goto :fail)
if not defined WEXE     (echo [ERROR] wluau.exe missing & goto :fail)
if not defined COMPILER (echo [ERROR] luau-compile.exe missing & goto :fail)
if not defined DLL      (echo [ERROR] luau.dll missing & goto :fail)

copy /Y "%INTERP%"   "%DIST%\luau.exe"  >nul
copy /Y "%WEXE%"     "%DIST%\wluau.exe" >nul
copy /Y "%COMPILER%" "%DIST%\luauc.exe" >nul
copy /Y "%DLL%"      "%DIST%\luau.dll"  >nul
if defined IMP copy /Y "%IMP%" "%DIST%\lib\luau.lib" >nul

copy /Y "%ROOT%\VM\include\*.h"            "%DIST%\include\"       >nul
copy /Y "%ROOT%\Compiler\include\*.h"      "%DIST%\include\"       >nul
copy /Y "%ROOT%\CodeGen\include\luacodegen.h" "%DIST%\include\"   >nul
copy /Y "%ROOT%\Require\include\Luau\Require.h" "%DIST%\include\Luau\" >nul

echo [4/4] Smoke test
> "%TEMP%\_t.luau" echo local s=0 for i=1,1000000 do s=s+i%%7 end print("hello from luau", s, os.exit ~= nil, io.write ~= nil)
"%DIST%\luau.exe" "%TEMP%\_t.luau"
if errorlevel 1 (echo [ERROR] luau.exe smoke test failed & goto :fail)
echo --- codegen:
"%DIST%\luau.exe" --codegen "%TEMP%\_t.luau"
if errorlevel 1 (echo [WARN] --codegen run failed)
del "%TEMP%\_t.luau" >nul 2>nul

echo.
echo [SUCCESS] %DIST%
dir /b "%DIST%"
pause
exit /b 0

:fail
echo.
echo [ERROR] Build failed.
pause
exit /b 1
